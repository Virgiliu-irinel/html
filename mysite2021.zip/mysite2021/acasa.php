<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Acasa</title>
</head>

<body>
	<h2>Contact</h2>
	<?php include("html/header.html");?>
	<?php include("html/acasa.html");?>
	<?php include("html/footer.html");?>
</body>
</html>