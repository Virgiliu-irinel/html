<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Despre noi</title>
</head>

<body>
	<h1>Pagina despre noi</h1>
	<?php include("html/header.html");?>
	<?php include("html/despre.html");?>
	<?php include("html/footer.html");?>
</body>
</html>