<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Contact</title>
</head>

<body>
	<h2>Contact</h2>
	<?php include("html/header.html");?>
	<?php include("html/contact.html");?>
	<?php include("html/footer.html");?>
</body>
</html>