<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Proiect nou 2021</title>
	<?php include("html/head.html");?>
	<style type="text/css">
	.container {
    padding: 20px;
    
    </style>
	
	
</head>

<body>


<div class="container">
	<?php $page = 'acasa';?>
	<?php include("html/header.php");?>
	<?php include("html/banner.html");?>
	<?php include("html/acasa.html");?>
	<?php include("html/footer.html");?>
	
		
</div>
</body>
</html>