<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
</head>

<body>
	<h1>Contact</h1>
	<?php include("html/header.html");?>
	<?php include("html/contact.html");?>
	<?php include("html/footer.html");?>
</body>
</html>