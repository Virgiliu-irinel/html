<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Proiect nou 2021</title>
	<?php include("html/head.html");?>
</head>

<body>
<div class="container">

	<?php $page="primul div";?>
	<?php include("html/header.php");?>
	<?php include("html/div.html");?>
	<?php include("html/footer.html");?>
	


		
</div>
</body>
</html>