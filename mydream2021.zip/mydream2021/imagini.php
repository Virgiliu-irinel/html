<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Proiect nou 2021</title>
	<?php include("html/head.html");?>
</head>

<body>

	<?php $page="imagini demo si harti mapate";?>
	<?php include("html/header.php");?>
	<?php include("html/imagini.html");?>
	<?php include("html/footer.html");?>
</body>
</html>