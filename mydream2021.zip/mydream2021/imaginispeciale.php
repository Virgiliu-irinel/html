<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
	<?php include("html/head.html");?>
</head>

<body>

	<?php $page="imagini speciale";?>
	<?php include("html/header.php");?>
	<?php include("html/imaginispeciale.html");?>
	<?php include("html/footer.html");?>
</body>
</html>