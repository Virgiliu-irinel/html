<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
</head>

<body>
	<h1>Proiect nou 2021</h1>
	<?php include("html/header.html");?>
	<?php include("html/imaginispeciale.html");?>
	<?php include("html/footer.html");?>
</body>
</html>