<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Acasa</title>
</head>

<body>
	<?php include("html/header.html");?>
	<?php include("html/acasa.html");?>
	<?php include("html/footer.html");?>
</body>
</html>