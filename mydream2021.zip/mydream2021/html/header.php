<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="/mydream2021/assets/css/style.css" rel="stylesheet" type="text/css">
<style type="text/css">
span {
    color: hsla(0,0%,0%,1.00);
    font-family: allura;
    font-style: normal;
    font-weight: 400;
    text-align: left;
    width: 100%;
    height: 50px;
    margin: 5px;
    padding: 5px;
    max-width: 500px;
    font-size: 50px;
    vertical-align: center;
}
</style>

<header class="header" id="header"></header>
	<!--The following script tag downloads a font from the Adobe Edge Web Fonts server for use within the web page. We recommend that you do not modify it.--><script>var __adobewebfontsappname__="dreamweaver"</script><script src="http://use.edgefonts.net/allura:n4:default.js" type="text/javascript"></script>
<div>
		<img src="/mydream2021/assets/images/logo.png"/>
		<span>Proiect 2021</span>
    </div>
	
<nav class="nav">
		    
		    <ul>				
				<li <?php if(isset($page) && $page =='acasa'):?>class="activ" <?php endif?>><a href="index.php">Acasa</a></li>
				&nbsp;&nbsp;&nbsp;		      
		     	 <li <?php if($page =="despre"):?> class="activ"<?php endif;?>>
				  <a  href="despre.php" tabindex="2" title="Despre noi" accesskey="D">Despre noi</a></li> 
		      		&nbsp;&nbsp;&nbsp;
		      	<li <?php if($page =="contact"):?> class="activ"<?php endif;?>>
				  <a href="contact.php" tabindex="3" title="Contact" accesskey="C">Contact</a></li> 
		      		&nbsp;&nbsp;&nbsp;
			  	<li <?php if($page =="text"):?> class="activ"<?php endif;?>>
				  <a href="text.php" tabindex="4" title="Text" accesskey="T">Text</a></li>
					&nbsp;&nbsp;
			  	<li <?php if($page =="linkuri"):?> class="activ"<?php endif;?>>
				  <a href="linkuri.php" tabindex="5" title="Ancore" accesskey="A">Linkuri</a></li>
					&nbsp;&nbsp;&nbsp;
			  	<li <?php if($page =="imagini"):?> class="activ"<?php endif;?>>
				  <a href="imagini.php" tabindex="6" title="Ancore" accesskey="L">imagini demo si harti mapate</a></li>
					&nbsp;&nbsp;&nbsp;
			 	 <li <?php if($page =="imagini speciale"):?> class="activ"<?php endif;?>>
				  <a href="imaginispeciale.php" tabindex="7" title="Ancore" accesskey="i">Imagini speciale</a></li>
					&nbsp;&nbsp;&nbsp;
				<li <?php if($page =="primul div"):?> class="activ"<?php endif;?>>
					<a href="div.php" tabindex="9" title="Ancore" accesskey="j">Primul div</a></li>
				
   		 	</ul>
		    
  
</nav>

