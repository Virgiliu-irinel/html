<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Despre noi</title>
	<?php include("html/head.html");?>
</head>

<body>
	<h1>Pagina de LINKURI</h1>
	<?php include("html/header.html");?>
	<?php include("html/link.html");?>
	<?php include("html/footer.html");?>
</body>
</html>